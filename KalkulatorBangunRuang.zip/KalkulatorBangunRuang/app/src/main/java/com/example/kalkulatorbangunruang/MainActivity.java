package com.example.kalkulatorbangunruang;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText panjang, lebar, tinggibalok;
    private EditText sisi;
    private EditText tinggiprisma,jari;
    private TextView tvHasil;
    private Button btnbalok;
    private Button btnkubus;
    private Button btntabung;
    private double sHasil = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnbalok = findViewById(R.id.button_balok);
        btnkubus = findViewById(R.id.button_kubus);
        btntabung = findViewById(R.id.button_prisma);
        panjang = findViewById(R.id.panjang);
        lebar = findViewById(R.id.lebar);
        tinggibalok = findViewById(R.id.tinggibalok);
        tinggiprisma= findViewById(R.id.tinggiprisma);
        tvHasil = findViewById(R.id.hasil);
        jari = findViewById(R.id.jari);
        sisi = findViewById(R.id.sisi1);

        btnbalok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double Panjang = Double.parseDouble(panjang.getText().toString());
                    Double Lebar = Double.parseDouble(lebar.getText().toString());
                    Double Tinggi = Double.parseDouble(tinggibalok.getText().toString());


                    Double balok =  Panjang * Lebar * Tinggi;
                    tvHasil.setText(String.valueOf(balok));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btnkubus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double Sisi = Double.parseDouble(sisi.getText().toString());


                    Double kubus = Sisi * Sisi * Sisi;
                    tvHasil.setText(String.valueOf(kubus));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btntabung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double PHI = 3.14;
                try {
                    Double Jari = Double.parseDouble(jari.getText().toString());
                    Double Tinggi1 = Double.parseDouble(tinggiprisma.getText().toString());

                    Double prisma = PHI * Jari * Tinggi1;
                    tvHasil.setText(String.valueOf(prisma));

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Field tidak boleh kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });


    }
}
